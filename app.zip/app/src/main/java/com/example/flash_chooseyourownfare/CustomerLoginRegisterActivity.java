package com.example.flash_chooseyourownfare;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class CustomerLoginRegisterActivity extends AppCompatActivity {
    private Button     customerLoginButton ;
    private Button     customerRegisterButton;
    private TextView   customerStatus;
    private TextView   customerRegisterLink;
    private EditText   EmailCustomer;
    private EditText   PasswordCustomer;
    private FirebaseAuth mAuth;
    private ProgressDialog loadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_login_register);

        customerLoginButton    = (Button)findViewById(R.id.customer_login_button);
        customerRegisterButton =(Button)findViewById(R.id.customer_Register_buttons);
        customerStatus   =(TextView)findViewById(R.id.customer_status);
        customerRegisterLink = (TextView)findViewById(R.id.customer_registor_link);
        EmailCustomer          =(EditText)findViewById(R.id.email_customer);
        PasswordCustomer       =(EditText)findViewById(R.id.password_customer);
        mAuth                 =FirebaseAuth.getInstance();      //this call the Authentication of the captain
        loadingBar            =new ProgressDialog(this);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        customerRegisterButton.setVisibility(View.INVISIBLE);
        customerRegisterButton.setEnabled(false);


        customerRegisterLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                customerLoginButton.setVisibility(View.INVISIBLE);
                customerLoginButton.setEnabled(true);
                customerRegisterLink.setVisibility(View.INVISIBLE);

                customerStatus.setText("Register Gaurdian");
                customerRegisterButton.setVisibility(View.VISIBLE);
                customerRegisterButton.setEnabled(true);
            }
        });
//------------------------------------------------------------------------------------------------------------------------------------
        customerLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = EmailCustomer.getText().toString();      //this read the emailtext
                String password = PasswordCustomer.getText().toString();    //this read the passwordtext

                LoginCustomer(email,password);

            }
        });
        customerRegisterButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                String email      = EmailCustomer.getText().toString();      //this read the emailtext
                String password   =PasswordCustomer.getText().toString();    //this read the passwordtext

                RegisterCustomers(email,password);                             //Registercustomer method is invoked here
            }
        });

      }
    //---------------------------------------------------------------------------------------------------------------------------------
       private void LoginCustomer(String email, String password) {
           if (TextUtils.isEmpty(email)) {
               Toast.makeText(CustomerLoginRegisterActivity.this, "Please Enter The Email..", Toast.LENGTH_LONG).show();
           }
           if (TextUtils.isEmpty(password)) {
               Toast.makeText(CustomerLoginRegisterActivity.this, "Please Enter The Password..", Toast.LENGTH_LONG).show();
           } else {
               loadingBar.setTitle("Gaurdian Login");
               loadingBar.setMessage("Please Wait, while we are Logging in Your Account");
               loadingBar.show();

               mAuth.signInWithEmailAndPassword(email, password)    // this is the firebase authentication syntax to call
                       .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                           @Override
                           public void onComplete(@NonNull Task<AuthResult> task) {
                               if (task.isSuccessful()) {
                                   Toast.makeText(CustomerLoginRegisterActivity.this, "Welcome ,You are Logged in  ", Toast.LENGTH_SHORT).show();
                                   Intent customerIntent = new Intent(getApplicationContext(), StudentMapsActivity.class);
                                   startActivity(customerIntent);
                                   loadingBar.dismiss();
                               } else {
                                   Toast.makeText(CustomerLoginRegisterActivity.this, ": Login Unsuccessful ,Please Try Again ", Toast.LENGTH_SHORT).show();
                                   loadingBar.dismiss();
                               }
                           }
                       });
           }


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

       }

       private void RegisterCustomers(String email, String password) {
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(CustomerLoginRegisterActivity.this, "Please Enter The Email..", Toast.LENGTH_LONG).show();
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(CustomerLoginRegisterActivity.this, "Please Enter The Password..", Toast.LENGTH_LONG).show();
        } else {
            loadingBar.setTitle("Gaurdian Registration");
            loadingBar.setMessage("Please Wait, while we are Registring Your Account");
            loadingBar.show();

            mAuth.createUserWithEmailAndPassword(email, password)    // this is the firebase authentication syntax to call
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(CustomerLoginRegisterActivity.this, "Hurrah ! Registration Complete ", Toast.LENGTH_SHORT).show();

                                Intent customerIntent = new Intent(getApplicationContext(),StudentInfo.class);
                                startActivity(customerIntent);
                                loadingBar.dismiss();
                            } else {
                                Toast.makeText(CustomerLoginRegisterActivity.this, ": Registration Unsuccessful ,Please Try Again ", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();
                            }
                        }
                    });




        }


    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
public boolean onCreateOptionsMenu(Menu menu)
{
    MenuInflater menuInflater = getMenuInflater();      // it inflate the menu item in the code and its xml file will be too inflated
    menuInflater.inflate(R.menu.menu, menu);

    return super.onCreateOptionsMenu(menu);
}


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

        if (item.getItemId() == R.id.Help) {
            Intent mailIntent = new Intent(Intent.ACTION_VIEW);
            Uri data = Uri.parse("mailto:?subject=" + " Subject of Your Query...  " + "&body=" + " Please Write your Query... " + "&to=" + "pkasaudhan93@gmail.com");
            mailIntent.setData(data);
            startActivity(mailIntent);
            return true;
        } else if (item.getItemId() == R.id.About) {

            Intent intent = new Intent(getApplicationContext(), feedback.class);
            startActivity(intent);

            return true;
        } else if (item.getItemId() == R.id.Share) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,
                    "Hey check out my app at: https://play.google.com/store/apps/details?id=com.google.android.apps.plus");
            sendIntent.setType("text/plain");
            startActivity(sendIntent);

        }


        return false;
    }


}
