package com.example.flash_chooseyourownfare;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CaptainMapActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        com.google.android.gms.location.LocationListener


        {
            Button start;
    private GoogleMap mMap;
    GoogleApiClient googleApiClient;
    Location lastLocation;
    LocationRequest locationRequest;
    private MarkerOptions place1, nagli, place2,adobe;

    private Button        Captainstartbutton;
    private Button        Captainlogoutbutton;
    private FirebaseAuth  mAuth;
    private FirebaseUser  currentUser;
    private Bitmap smallMarker;
    private Bitmap smallMaker2;
    private boolean currentLogOutDriverStatus=false;

//---------------------------------------------------------------------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_captain_map_actiivity);
   //================================================================================================
        int height = 150;                                 // defining size of the marker
        int width = 150;
        BitmapDrawable bitmapdraw = (BitmapDrawable)getResources().getDrawable(R.drawable.iconer);
        BitmapDrawable bitmapdraw2 = (BitmapDrawable)getResources().getDrawable(R.drawable.student);

        Bitmap b = bitmapdraw.getBitmap();
        Bitmap c = bitmapdraw2.getBitmap();

        smallMarker = Bitmap.createScaledBitmap(b, width, height, false);
        smallMaker2= Bitmap.createScaledBitmap(c, width, height, false);


        //==============================================================================================
        mAuth=FirebaseAuth.getInstance();
        currentUser=mAuth.getCurrentUser();
        Captainstartbutton =(Button)findViewById(R.id.captain_start_button);
        Captainlogoutbutton = (Button)findViewById(R.id.captain_logout_button);

        //==============================================================================================
        Captainstartbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),pick.class);
                startActivity(i);

            }
        });



     //=====================================================================================================
      //in this we send sms to defined ltitude and longitude

       Button sendsms=(Button)findViewById(R.id.send_sms);
      sendsms.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {


            String number = null;
              String number1 = null;
              String number2 = null;

              String message = null;


            Gps_tracker_forSMS g = new Gps_tracker_forSMS(getApplicationContext());
            Location l = g.getLocation();
            if (l != null) {
                double lat = l.getLatitude();
                double lon = l.getLongitude();
                message ="Emergency!!! Reach to Loction fast\n\n"+"https://www.google.com/maps/dir/?api=1&destination=" + lat+ "," + lon + "&travelmode=driving";
                number = "9839076595";
                number1="8299393376";
                number2="7048944235";

            }
            //Getting intent and PendingIntent instance
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);

            //Get the SmsManager instance and call the sendTextMessage method to send message
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(number, null, message, pi, null);
              sms.sendTextMessage(number1, null, message, pi, null);
              sms.sendTextMessage(number2, null, message, pi, null);


              Toast.makeText(getApplicationContext(), "Message Sent successfully!",
                    Toast.LENGTH_LONG).show();
        }

    });







        //===============================================================================================

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

checkLocationCommandPermisson();                 //checkLocationCommandPermisson method called here

       Captainlogoutbutton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               currentLogOutDriverStatus=true;
               DisconnectCaptain();
               mAuth.signOut();                    // now the driver will be signed out from the firebase
               LogoutCaptain();
               Intent WelcomeIntent =new Intent(getApplicationContext(),WelcomeActivity.class);
               startActivity(WelcomeIntent);


               // this method is  created to move the driver to the welcome Activity
           }
       });
    }

            private void LogoutCaptain()
            {
                Intent WelcomeIntent =new Intent(getApplicationContext(),WelcomeActivity.class);
                WelcomeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);     // it clear the present map activity
                startActivity(WelcomeIntent);
                finish();
            }

            //--------------------------------------------------------------------------------------------------------------------------
    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        mMap = googleMap;
        // Add a marker




        buildGoogleApiClient();                      // Method called here
mMap.setMyLocationEnabled(true);
    }
//-------------------------------------------------------------------------------------------------------------------------
            @Override
            public void onConnected(@Nullable Bundle bundle) {                       //GoogleApiClient.ConnectionCallbacks
                LocationRequest locationRequest =new LocationRequest();
                locationRequest.setInterval(4000);
                locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

                    LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient,locationRequest,this);


    }

            @Override
            public void onConnectionSuspended(int i) {                              //GoogleApiClient.ConnectionCallbacks

            }

            @Override
            public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                Toast.makeText(this, "You Are Out Of Service", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onLocationChanged(Location location) {                    //com.google.android.gms.location.LocationListener

                lastLocation =location;
                LatLng latLng =new LatLng(location.getLatitude(),location.getLongitude());

                mMap.animateCamera(CameraUpdateFactory.zoomTo(15f));

                MarkerOptions mp = new MarkerOptions();

                mp.position(new LatLng(location.getLatitude(), location.getLongitude()));
                mp.icon(BitmapDescriptorFactory.fromBitmap(smallMarker));

                mp.title("Bus 1 ");

                mMap.addMarker(mp);

                place1 = new MarkerOptions().position(new LatLng(location.getLatitude(), location.getLongitude())).title("Location 1");
                MarkerOptions place2=new MarkerOptions();
                place2.position(new LatLng(28.5192, 77.3653)).title("Student = Neeraj Kumar");
place2.icon(BitmapDescriptorFactory.fromBitmap(smallMaker2));
mMap.addMarker(place2);



                LatLng kosmos = new LatLng(28.5192, 77.3653);
                LatLng nagli = new LatLng(28.5014, 77.3762);
                LatLng adobe = new LatLng(28.5071, 77.3787);
                mMap.addMarker(place2);



                mMap.addPolyline(new PolylineOptions()
                       .add(latLng)
                       .add(nagli)
                       .add(adobe)
                       .add(kosmos)

                       .width(10f)
                       .color(Color.BLUE)

               );
               mMap.addCircle(
                      new CircleOptions()
                              .center(kosmos)
                              .radius(50.0)
                       .strokeWidth(3f)
                       .strokeColor(Color.RED)
                       .fillColor(Color.argb(70,50,50,50))
               );


          // now we are taking geofire as it shows the driver moving , availibility and so on.
                String userID = FirebaseAuth.getInstance().getCurrentUser().getUid();      // driver user id
                DatabaseReference DriverAvailibilityRef = FirebaseDatabase.getInstance().getReference().child("Driver Availibility");

                GeoFire geoFire=new GeoFire(DriverAvailibilityRef);
                geoFire.setLocation(userID,new GeoLocation(location.getLatitude(),location.getLongitude()));

            }
//-----------------------------------------------------------------------------------------------------------------------
        // this method is created for the google Api client

                protected synchronized void buildGoogleApiClient()
                {
                    googleApiClient=new GoogleApiClient.Builder(this)
                            .addConnectionCallbacks(this)
                            .addOnConnectionFailedListener(this)
                            .addApi(LocationServices.API)
                            .build();
                    googleApiClient.connect();

                }

            @Override
            protected void onStop() {               // this method is created when the driver stop its service.

                super.onStop();
                if(!currentLogOutDriverStatus) {
                    DisconnectCaptain();
                }
            }

            private void DisconnectCaptain() {
                String userID = FirebaseAuth.getInstance().getCurrentUser().getUid();      // driver user id
                DatabaseReference DriverAvailibilityRef = FirebaseDatabase.getInstance().getReference();

                GeoFire geoFire=new GeoFire(DriverAvailibilityRef);
                geoFire.removeLocation(userID);
            }
//------------------------------------------------------------------------------------------------------------------------            //
private void checkLocationCommandPermisson() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
    {
        if(!(ContextCompat.checkSelfPermission(CaptainMapActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED))
        {

            Intent intent =new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+getPackageName()));
            startActivity(intent);
            finish();
            Toast.makeText(this, "Please Enable The Location Permisson  of Your Application  ", Toast.LENGTH_SHORT).show();
        }

    }
}
//=====================================================================================================================




        }

