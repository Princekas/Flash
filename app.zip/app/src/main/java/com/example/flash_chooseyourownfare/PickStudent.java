package com.example.flash_chooseyourownfare;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class PickStudent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_student);



    }
}
