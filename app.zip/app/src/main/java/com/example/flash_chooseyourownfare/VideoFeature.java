package com.example.flash_chooseyourownfare;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class VideoFeature extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_feature);
    }
}
