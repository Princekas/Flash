package com.example.flash_chooseyourownfare;

import android.app.PendingIntent;
import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class pick extends AppCompatActivity {
Button pick;
    String arr[]=new String[5];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick);
       // pick=( Button ) findViewById(R.id.captain_start);
        /*webView=(WebView) findViewById(R.id.web);
        String l1="Sector+14,+lucknow";
        String l2="Sector+8,+lucknow";
        String l3="Sector+10,+lucknow";
        arr[0]=l1;
        arr[1]=l2;
        arr[2]=l3;


        webView.loadUrl("https://www.google.com/maps/dir/?api=1&"+para);
        WebSettings websettings= webView.getSettings();
        websettings.setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());*/
pick=findViewById(R.id.captain_start);
        String l1="Sector+14,+lucknow";
        String l2="Sector+8,+lucknow";
        String l3="Sector+10,+lucknow";
        final String sch="city+montessori+school,+vishal+khand+2,+lucknow";
        arr[0]=l1;
        arr[1]=l2;
        arr[2]=l3;
        final int[] i = new int[1];
        i[0] = 1;



        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i[0]++;
                if(pick.getText()!="School")
                {
                    pick.setText("pick " + i[0]);
                    Uri gmmIntentUri = Uri.parse("google.navigation:q=" + arr[i[0] - 2]);
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                    if(arr[i[0]-1]==null)
                    {
                        pick.setText("School");
                    }
                }
                else
                {
                    Uri gmmIntentUri = Uri.parse("google.navigation:q=" + sch);
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }
            }
        });
        Button sendsms=(Button)findViewById(R.id.captain_alert);
        sendsms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String number = null;
                String number1 = null;
                String number2 = null;

                String message = null;


                Gps_tracker_forSMS g = new Gps_tracker_forSMS(getApplicationContext());
                Location l = g.getLocation();
                if (l != null) {
                    double lat = l.getLatitude();
                    double lon = l.getLongitude();
                    message ="Emergency!!! Reach to Loction fast\n\n"+"https://www.google.com/maps/dir/?api=1&destination=" + lat+ "," + lon + "&travelmode=driving";
                    number = "9839076595";
                    number1="8299393376";
                    number2="7048944235";

                }
                //Getting intent and PendingIntent instance
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                PendingIntent pi = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);

                //Get the SmsManager instance and call the sendTextMessage method to send message
                SmsManager sms = SmsManager.getDefault();
                sms.sendTextMessage(number, null, message, pi, null);
                sms.sendTextMessage(number1, null, message, pi, null);
                sms.sendTextMessage(number2, null, message, pi, null);


                Toast.makeText(getApplicationContext(), "Message Sent successfully!",
                        Toast.LENGTH_LONG).show();
            }

        });







    }

}