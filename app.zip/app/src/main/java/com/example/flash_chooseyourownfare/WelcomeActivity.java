package com.example.flash_chooseyourownfare;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {
    private Button WelcomeDriverButton;
    private Button WelcomeCustomerButton;
    private VideoView video;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        WelcomeDriverButton = (Button)findViewById(R.id.WelcomeDriverButton);
        WelcomeCustomerButton = (Button)findViewById(R.id.WelcomeCustomerButton);

        video = findViewById(R.id.videoView);
        String path = "android.resource://" + getPackageName() + "/" + R.raw.please;
        video.setVideoURI(Uri.parse(path));

        video.start();

        video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {   // this method is called to loop the video
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mediaPlayer.setLooping(true);            }
        });


        WelcomeCustomerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent WelcomeCutomerButton = new Intent(getApplicationContext(),CustomerLoginRegisterActivity.class);
                startActivity(WelcomeCutomerButton);
            }
        });
        WelcomeDriverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent WelcomeDriverButton = new Intent(getApplicationContext(),DriverLoginRegisterActivity.class);
                startActivity(WelcomeDriverButton);
            }
        });
    }
}
