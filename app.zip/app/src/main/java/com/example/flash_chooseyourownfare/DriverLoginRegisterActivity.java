package com.example.flash_chooseyourownfare;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class DriverLoginRegisterActivity extends AppCompatActivity {

    private Button CaptainLoginButton;
    private Button CaptainRegisterButton;
    private TextView CaptainStatus;
    private TextView CaptainRegisterLink;
    private EditText EmailCaptain;
    private EditText PasswordCaptain;
    private FirebaseAuth mAuth;
    private ProgressDialog loadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_login_register);

        CaptainLoginButton = (Button) findViewById(R.id.captain_login_button);
        CaptainRegisterButton = (Button) findViewById(R.id.captain_Register_button);
        CaptainStatus = (TextView) findViewById(R.id.captain_status);
        CaptainRegisterLink = (TextView) findViewById(R.id.captain_registor_link);
        EmailCaptain = (EditText) findViewById(R.id.email_captain);
        PasswordCaptain = (EditText) findViewById(R.id.password_captain);
        mAuth = FirebaseAuth.getInstance();      //this call the Authentication of the captain
        loadingBar = new ProgressDialog(this);

        CaptainRegisterButton.setVisibility(View.INVISIBLE);
        CaptainRegisterButton.setEnabled(false);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        CaptainRegisterLink.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                CaptainLoginButton.setVisibility(View.INVISIBLE);
                CaptainLoginButton.setEnabled(true);
                CaptainRegisterLink.setVisibility(View.INVISIBLE);

                CaptainStatus.setText("Register Captain");
                CaptainRegisterButton.setVisibility(View.VISIBLE);
                CaptainRegisterButton.setEnabled(true);
            }
        });

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        CaptainRegisterButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = EmailCaptain.getText().toString();      //this read the emailtext
                String password = PasswordCaptain.getText().toString();    //this read the passwordtext

                RegisterCaptain(email, password);                             //RegisterDriver method is invoked here
            }
        });
//-----------------------------------------------------------------------------------------------------------------------------------
        CaptainLoginButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = EmailCaptain.getText().toString();      //this read the emailtext
                String password = PasswordCaptain.getText().toString();    //this read the passwordtext

                LoginCaptain(email,password);

            }
        });

      }
//---------------------------------------------------------------------------------------------------------------------------------
      private void LoginCaptain(String email, String password) {
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(DriverLoginRegisterActivity.this, "Please Enter The Email..", Toast.LENGTH_LONG).show();
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(DriverLoginRegisterActivity.this, "Please Enter The Password..", Toast.LENGTH_LONG).show();
        } else {
            loadingBar.setTitle("Captain Login");
            loadingBar.setMessage("Please Wait, while we are Logging in Your Account");
            loadingBar.show();

            mAuth.signInWithEmailAndPassword(email, password)    // this is the firebase authentication syntax to call
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(DriverLoginRegisterActivity.this, "Welcome  ", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();
                                Intent CaptainIntent = new Intent(getApplicationContext(),CaptainMapActivity.class);
                                startActivity(CaptainIntent);
                            } else {
                                Toast.makeText(DriverLoginRegisterActivity.this, ": Login Unsuccessful ,Please Try Again ", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();
                            }
                        }
                    });
        }


      }

    //-----------------------------------------------------------------------------------------------------------------------------------
      private void RegisterCaptain(String email, String password) {                 //Method is Created
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(DriverLoginRegisterActivity.this, "Please Enter The Email..", Toast.LENGTH_LONG).show();
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(DriverLoginRegisterActivity.this, "Please Enter The Password..", Toast.LENGTH_LONG).show();
        } else {
            loadingBar.setTitle("Captain Registration");
            loadingBar.setMessage("Please Wait, while we are Registring Your Account");
            loadingBar.show();

            mAuth.createUserWithEmailAndPassword(email, password)    // this is the firebase authentication syntax to call
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(DriverLoginRegisterActivity.this, "Hurrah ! Registration Complete ", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();
                                Intent CaptainIntent = new Intent(getApplicationContext(),DriverInfo.class);
                                startActivity(CaptainIntent);
                            } else {
                                Toast.makeText(DriverLoginRegisterActivity.this, ": Registration Unsuccessful ,Please Try Again ", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();
                            }
                        }
                    });
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater menuInflater = getMenuInflater();      // it inflate the menu item in the code and its xml file will be too inflated
        menuInflater.inflate(R.menu.menu, menu);

        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

        if (item.getItemId() == R.id.Help) {
            Intent mailIntent = new Intent(Intent.ACTION_VIEW);
            Uri data = Uri.parse("mailto:?subject=" + " Subject of Your Query...  " + "&body=" + " Please Write your Query... " + "&to=" + "pkasaudhan93@gmail.com");
            mailIntent.setData(data);
            startActivity(mailIntent);
            return true;
        } else if (item.getItemId() == R.id.About) {

            Intent intent = new Intent(getApplicationContext(), feedback.class);
            startActivity(intent);

            return true;
        } else if (item.getItemId() == R.id.Share) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,
                    "Hey check out my app at: https://play.google.com/store/apps/details?id=com.google.android.apps.plus");
            sendIntent.setType("text/plain");
            startActivity(sendIntent);

        }


        return false;
    }

}

